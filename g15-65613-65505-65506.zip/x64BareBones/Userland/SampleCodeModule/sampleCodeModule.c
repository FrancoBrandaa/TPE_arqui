/* sampleCodeModule.c */
#include <libc.h>
#include <shell.h>
int main() {
    shell();
    return 0;
}